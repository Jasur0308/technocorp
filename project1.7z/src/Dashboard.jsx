import React from 'react';

const StatsCard = ({ title, value, icon }) => (
  <div className="bg-gray-100 p-4 rounded shadow text-center w-40">
    <div className="text-2xl mb-1">{icon}</div>
    <div className="font-bold text-lg">{value}</div>
    <div className="text-sm">{title}</div>
  </div>
);

export default StatsCard;