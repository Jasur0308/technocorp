import { Line } from 'react-chartjs-2';
import { Chart as ChartJS, LineElement, CategoryScale, LinearScale, PointElement, Tooltip, Legend } from 'chart.js';
import 'chart.js/auto';

ChartJS.register(LineElement, CategoryScale, LinearScale, PointElement, Tooltip, Legend);

const Chart = () => {
  const labels = Array.from({ length: 14 }, (_, i) => i);
  const data = {
    labels,
    datasets: [
      {
        label: 'sin(x)',
        data: labels.map(x => Math.sin(x)),
        fill: false,
        borderColor: 'rgb(255, 99, 132)',
        tension: 0.3,
      },
      {
        label: 'cos(x)',
        data: labels.map(x => Math.cos(x)),
        fill: false,
        borderColor: 'rgb(54, 162, 235)',
        tension: 0.3,
      },
    ],
  };

  return <Line data={data} />;
};

export default Chart;