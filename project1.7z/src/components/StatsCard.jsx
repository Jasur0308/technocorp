import Sidebar from './components/Sidebar';
import Chart from './components/Chart';
import StatsCard from './components/StatsCard';

const Dashboard = () => {
  const stats = [
    { title: 'Total Users', value: 2540, icon: '👤' },
    { title: 'New Users', value: 120, icon: '➕' },
    { title: 'Total Shop', value: 656, icon: '🛒' },
    { title: 'Total Orders', value: 9540, icon: '🏷️' },
    { title: 'Pending Orders', value: 10, icon: '⏳' },
    { title: 'Online Orders', value: 8540, icon: '🌐' },
  ];

  return (
    <div className="flex">
      <Sidebar />
      <main className="p-6 flex-1">
        <h1 className="text-2xl font-semibold mb-4">Bosh sahifa</h1>
        <section className="bg-white p-4 rounded shadow mb-6">
          <h2 className="text-lg font-medium mb-2">Site Analytics</h2>
          <Chart />
        </section>
        <div className="flex gap-4 flex-wrap">
          {stats.map((stat, idx) => (
            <StatsCard key={idx} {...stat} />
          ))}
        </div>
      </main>
    </div>
  );
};

export default Dashboard;