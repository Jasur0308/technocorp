import React from 'react';

const Sidebar = () => {
  const menuItems = ['Bosh sahifa', 'Administratorlar', 'DAI', 'Migratsiya', 'Hududlar', 'Rollar', 'Manba', 'Sub\'ektlar', 'Vakolatli organlar', 'Rezolutsiyalar', 'Javob xatlari', 'Murojaat turi', 'Shapes', 'Natija'];

  return (
    <div className="w-64 bg-gray-800 text-white h-screen p-4">
      <h2 className="text-xl font-bold mb-4">Technocorp Admin</h2>
      <ul>
        {menuItems.map((item, idx) => (
          <li key={idx} className="py-2 hover:bg-gray-700 cursor-pointer px-2 rounded">
            {item}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Sidebar;